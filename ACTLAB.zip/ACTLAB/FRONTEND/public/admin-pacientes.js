document.addEventListener("DOMContentLoaded", () => {
  // --- Lógica de pacientes ---
  const pacientes = [
    { id: 1, nombre: "Juan Pérez", edad: 32, genero: "Masculino", telefono: "999888777" },
    { id: 2, nombre: "María López", edad: 27, genero: "Femenino", telefono: "987654321" },
    { id: 3, nombre: "Carlos Ramírez", edad: 40, genero: "Masculino", telefono: "912345678" },
    { id: 4, nombre: "Ana Torres", edad: 22, genero: "Femenino", telefono: "956789012" },
  ];

  const tablaBody = document.querySelector("#tablaPacientes tbody");

  function cargarPacientes() {
    tablaBody.innerHTML = "";
    pacientes.forEach((p) => {
      const fila = document.createElement("tr");
      fila.innerHTML = `
        <td>${p.id}</td>
        <td>${p.nombre}</td>
        <td>${p.edad}</td>
        <td>${p.genero}</td>
        <td>${p.telefono}</td>
      `;
      tablaBody.appendChild(fila);
    });
  }

  cargarPacientes();

  // --- Buscador ---
  const inputBuscar = document.getElementById("buscarPaciente");
  if (inputBuscar) {
    inputBuscar.addEventListener("keyup", (e) => {
      const texto = e.target.value.toLowerCase();
      const filas = tablaBody.querySelectorAll("tr");
      filas.forEach((fila) => {
        const nombre = fila.children[1].textContent.toLowerCase();
        fila.style.display = nombre.includes(texto) ? "" : "none";
      });
    });
  }

  // --- Estadísticas (gráfico de ejemplo) ---
  const ctx = document.getElementById("chartPacientesGenero");
  if (ctx) {
    new Chart(ctx, {
      type: "pie",
      data: {
        labels: ["Masculino", "Femenino"],
        datasets: [
          {
            data: [
              pacientes.filter((p) => p.genero === "Masculino").length,
              pacientes.filter((p) => p.genero === "Femenino").length,
            ],
            backgroundColor: ["#3B82F6", "#EC4899"],
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom" } },
      },
    });
  }
});
